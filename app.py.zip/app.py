from flask import Flask, render_template, request
import numpy as np
import joblib
import string
from sklearn.feature_extraction.text import CountVectorizer

app = Flask(__name__)

model = joblib.load("model/logistic_regression_model.pkl")

vectorizer = joblib.load("model/count_vectorizer.pkl")

def preprocess_text(text):
    
    text = text.lower()
    
    text = text.translate(str.maketrans('', '', string.punctuation))
    return text
    
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST','GET'])
def predict():
    review_text = request.form['review']
    processed_text = preprocess_text(review_text)
    numeric_data = vectorizer.transform([processed_text])
    prediction = model.predict(numeric_data)[0]

    if prediction == 1:
        feedback_message = "This is a positive feedback."
    else:
        feedback_message = "This is a negative feedback."

    return render_template('result.html', review=review_text, prediction=prediction, feedback_message=feedback_message)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)

